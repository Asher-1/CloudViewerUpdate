LASzip
--------------------------------------------------------

https://laszip.org/

Testing
........................................................

.. image:: https://travis-ci.org/LASzip/LASzip.svg?branch=master
    :target: https://travis-ci.org/LASzip/LASzip
