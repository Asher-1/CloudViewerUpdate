<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pl_PL">
<context>
    <name>Page</name>
    <message>
        <location filename="page.ui" line="14"/>
        <source>Translations Example</source>
        <translation>Przykład obrazujący przekład na inny język</translation>
    </message>
    <message>
        <location filename="page.ui" line="36"/>
        <source>This is some text.</source>
        <translation>To jest pewien tekst.</translation>
    </message>
</context>
<context>
    <name>installscript</name>
    <message>
        <location filename="installscript.qs" line="64"/>
        <source>This is a dynamically created page.</source>
        <translation>Jest to strona utworzona dynamicznie.</translation>
    </message>
</context>
</TS>
