<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>Page</name>
    <message>
        <source>Translations Example</source>
        <translation>Beispiel für Übersetzungen</translation>
    </message>
    <message>
        <source>This is some text.</source>
        <translation>Dies ist ein Text.</translation>
    </message>
</context>
<context>
    <name>installscript</name>
    <message>
        <source>This is a dynamically created page.</source>
        <translation>Diese Seite wurde dynamisch erzeugt.</translation>
    </message>
</context>
</TS>
